package com.example;

import de.greenrobot.daogenerator.DaoGenerator;
import de.greenrobot.daogenerator.Entity;
import de.greenrobot.daogenerator.Schema;

public class DbGenerator {
    public static void main(String[] args) throws Exception {

        Schema schema = new Schema(1, "com.prance.greendao");
        addDevice(schema);
        addTransactionRecode(schema);
        try {
            new DaoGenerator().generateAll(schema, "E:/work/Pay/app/src/main/java-gen/");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void addTransactionRecode(Schema schema){
        Entity transactionRecord = schema.addEntity("TransactionRecord");
        transactionRecord.setHasKeepSections(true);
        transactionRecord.addStringProperty("name");
        transactionRecord.addStringProperty("transDate");
        transactionRecord.addStringProperty("goodsJO");
        transactionRecord.addStringProperty("goodsJA");
        transactionRecord.addStringProperty("discountAmount");//折扣
        transactionRecord.addStringProperty("totalAmount");//总金额
        transactionRecord.addStringProperty("cashAmount");//现金
        transactionRecord.addStringProperty("isReturn");//是否退款
        transactionRecord.addStringProperty("changeAmount");//找零
        transactionRecord.addStringProperty("receiver");//收款
        transactionRecord.addStringProperty("deviceId");//设备ID
        transactionRecord.addStringProperty("address");
        transactionRecord.addStringProperty("tell");//
        transactionRecord.addStringProperty("merchantName");//商户名
        transactionRecord.addStringProperty("merchantNo");//商户编号
        transactionRecord.addStringProperty("teminalNo");//终端号
        transactionRecord.addStringProperty("operateNo");//操作员ID
        transactionRecord.addStringProperty("cardNo");//卡
        transactionRecord.addStringProperty("orderId").primaryKey().index();//订单号
        transactionRecord.addStringProperty("ShouDanHang");//收单行
        transactionRecord.addStringProperty("FaKaHang");//发卡行
        transactionRecord.addStringProperty("expireDate");//有效期
        transactionRecord.addStringProperty("state");
        transactionRecord.addStringProperty("bachNo");//批次号
        transactionRecord.addStringProperty("voucherNo");//凭证号
        transactionRecord.addStringProperty("authNo");//授权码
        transactionRecord.addStringProperty("refNo");//参考号
        transactionRecord.addStringProperty("amount");//交易金额
        transactionRecord.addStringProperty("bankCardAmount");//银行卡交易金额
        transactionRecord.addStringProperty("createTime"); //订单创建时间
        transactionRecord.addStringProperty("transType");    //交易类型【微信/支付宝/现金/银行卡】
        transactionRecord.addStringProperty("remarks");//备注
        transactionRecord.addStringProperty("signPath"); //签名存储路径
    }

    private static void addDevice(Schema schema) {
        Entity newsDetail = schema.addEntity("Device");
        newsDetail.setHasKeepSections(true);
//        newsDetail.addStringProperty("id").primaryKey().autoincrement();
        newsDetail.addStringProperty("deviceId");
        newsDetail.addStringProperty("deviceNo").primaryKey();
        newsDetail.addStringProperty("phone");
        newsDetail.addStringProperty("factory");
        newsDetail.addStringProperty("deviceType");
        newsDetail.addBooleanProperty("isDefault");
        newsDetail.addStringProperty("deviceName");
    }
}
